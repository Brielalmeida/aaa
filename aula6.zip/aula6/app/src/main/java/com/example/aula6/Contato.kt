package com.example.aula6

data class Contato(
    var email : String = "",
    var nome: String = "",
    var telefone: String = ""
) {}
