package com.example.agenda.activity

import ContatoAdapter
import android.app.Activity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.agenda.R
import com.example.agenda.model.Contato

class ContatoListActivity : Activity() {
    override fun onCreate(bundle: Bundle?) {
        super.onCreate(bundle)
        setContentView(R.layout.contato_lista_layout)

        val b1 = intent.extras
        val lista = b1?.getSerializable("LISTA") as ArrayList<Contato> ?: ArrayList<Contato>()
        val recyclerView = findViewById<RecyclerView>(R.id.rcv_contato_lista)
        val adapter = ContatoAdapter(this, lista)
        recyclerView.adapter = adapter
        recyclerView.layoutManager = LinearLayoutManager(this)
    }
}